<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QuestionController extends Controller
{
    public function index(){
    	// echo "this is question page";
    	// return response()->json("this is question page");
    	return DB::table('question')->get();
    }

    public function show($id){
    	// echo "get question with id = ".$id;
    	return response()->json("get question with id = ".$id);
    }

    public function store(Request $request){
    	return response()->json([
    		"input"=>$request->all(),
    		"result"=>"store question with object from POST data"
    	]);
    }

    public function update(Request $request, $id){
    	return response()->json([
    		"input"=>$request->all(),
    		"result"=>"update question with id = ".$id." and object from PUT data"
    	]);
    }

    public function destroy($id){
    	return response()->json("delete question with id = ".$id);
    }
}
